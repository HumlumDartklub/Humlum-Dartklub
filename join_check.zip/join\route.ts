// app/api/join/route.ts
import { NextResponse } from "next/server";
export const revalidate = 0;

type JoinPayload = {
  name?: string;
  email?: string;
  phone?: string;
  package_id?: string;
  notes?: string;
  payment_method?: string; // "mobilepay" | "cash" (valgfri fra formular)
};

function toJsonSafe(text: string) {
  try { return text ? JSON.parse(text) : null; } catch { return null; }
}

export async function POST(req: Request) {
  // 1) Læs body som JSON – og håndter fejl pænt
  let payload: JoinPayload | null = null;
  try {
    payload = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Bad JSON body" }, { status: 400 });
  }

  // 2) Vælg webhook-URL: JOIN_WEBHOOK || SHEET_API_URL || NEXT_PUBLIC_SHEET_API
  const webhook =
    process.env.JOIN_WEBHOOK ||
    process.env.SHEET_API_URL ||
    process.env.NEXT_PUBLIC_SHEET_API;

  if (!webhook) {
    return NextResponse.json({ ok: false, error: "Missing webhook URL" }, { status: 500 });
  }

  // 3) Send som JSON til Apps Script (doPost) – og bed om JSON tilbage
  let upstream: Response;
  try {
    upstream = await fetch(webhook, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ tab: "JOIN", data: payload }),
      cache: "no-store",
    });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: String(e?.message || e) }, { status: 502 });
  }

  // 4) Læs svar robust (ingen “Unexpected end…”)
  const raw = await upstream.text().catch(() => "");
  const data = toJsonSafe(raw);

  // 5) Returnér ALTID JSON
  const ok = upstream.ok && (data?.ok ?? true);
  const status = ok ? 200 : (upstream.status || 502);

  return NextResponse.json(
    { ok, upstreamStatus: upstream.status, result: data ?? { raw } },
    { status }
  );
}
