// lib/sheetsWrite.ts
export async function upsertRow(_tab: string, _row: Record<string, any>) {
  throw new Error("Write-API ikke aktiveret endnu.");
}

export async function deleteRow(_tab: string, _id: string) {
  throw new Error("Write-API ikke aktiveret endnu.");
}
